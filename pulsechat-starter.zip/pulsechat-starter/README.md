# PulseChat starter (v0.1)

A responsive UI prototype for the PulseChat concept. Includes sample feed, story strip, local demo posting/likes, profile editing, discover UI, messaging mockup, and an 18+ confirmation gate for the random-chat screen.

## Run locally

Requires Node.js 20+ and npm.

```bash
npm install
npm start
```
Open the local URL shown by `serve`.

## Android APK scaffold

This project is prepared to be wrapped with Capacitor, but the APK has **not** been built. Building requires Android Studio / Android SDK and a signed or debug build environment.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, build a debug APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Capacitor's official docs: https://capacitorjs.com/docs/android

## Important current limitations

- Demo/sample content only; posts, likes, profile edits and chat are not stored in a shared database.
- Login/signup is not connected.
- Random chat is a UI simulation; no real user matching or video call is connected.
- The age checkbox is not age verification and can be bypassed; it is only a prototype gate.
- Do not publish this prototype as a real public social network before implementing authentication, database/storage rules, real age assurance suitable for the service, privacy/terms, moderation, report/block enforcement, rate limits, abuse handling, and security review.

## Recommended low-cost shared backend

Use Supabase (Auth + Postgres + Storage + Realtime) for shared accounts and social data. Use a separate WebRTC signaling/matching service for random video chat; use a TURN server for users behind restrictive networks. Keep service-role secrets on the server only. Configure Row Level Security before any public launch. A backend and deployment account still need to be created and connected.
